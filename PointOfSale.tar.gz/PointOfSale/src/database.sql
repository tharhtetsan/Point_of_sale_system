create database pointofsale;

use pointofsale;

create table brand
(
    brandid varchar(10) not null primary key,
    brandname varchar(30) 
    );
    
    create table type
(
    typeid varchar(10) not null primary key,
    typename varchar(30) 
    );
    
    
    create table merchandise
(
    merid varchar(10) not null primary key,
    brandid varchar(10) null foreign key references brand(brandid),
    typeid varchar(10) null foreign key references type(typeid)
    );